# localssl

One-command local HTTPS for development teams.

## Install

```bash
npm i -D localssl
npx localssl
```

## Commands

- `localssl` / `localssl use` - initialize + create project cert + configure framework
- `localssl init` - initialize machine CA and trust stores
- `localssl status` - check expiry and team sync status
- `localssl renew` - renew project cert
- `localssl trust` - import team public CAs from `localssl.json`
- `localssl qr` - serve CA certificate + print QR for phone install
- `localssl ci` - ephemeral cert setup for CI (`CI=true`)
- `localssl remove` - uninstall trust and local files

## Team sharing

`localssl.json` is safe to commit. It stores only public CA certificates.
